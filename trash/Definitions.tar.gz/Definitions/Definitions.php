<?php

namespace Hobosoft\MegaLoader\Definitions;

use Hobosoft\MegaLoader\AnyOf;
use Hobosoft\MegaLoader\SchemaInterface;
use Hobosoft\MegaLoader\Structure;
use Hobosoft\MegaLoader\Type;

class Definitions
{

    public static function __callStatic(string $name, array $args): Def
    {
        $type = new Type($name);
        if ($args) {
            $type->default($args[0]);
        }

        return $type;
    }


    public static function type(string $type): Type
    {
        return new Type($type);
    }


    public static function anyOf(mixed ...$set): AnyOf
    {
        return new AnyOf(...$set);
    }


    /**
     * @param  SchemaInterface[]  $items
     */
    public static function structure(array $items): Structure
    {
        return new Structure($items);
    }


    public function __construct(
        public string $name,
    )
    {

    }
}
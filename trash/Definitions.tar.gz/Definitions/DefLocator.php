<?php

namespace Hobosoft\MegaLoader\Definitions;

use Hobosoft\MegaLoader\Definitions\DefRoot;

class DefLocator extends DefRoot
{

}

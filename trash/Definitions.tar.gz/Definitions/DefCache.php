<?php

namespace Hobosoft\MegaLoader\Definitions;

use Hobosoft\MegaLoader\Definitions\Def;

class DefCache extends DefRoot
{

}
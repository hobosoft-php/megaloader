<?php

namespace Hobosoft\MegaLoader\Definitions;

use Hobosoft\MegaLoader\Definitions\Def;

class DefDecorator extends DefRoot
{

}
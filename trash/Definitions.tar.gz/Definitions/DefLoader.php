<?php

namespace Hobosoft\MegaLoader\Definitions;

use Hobosoft\MegaLoader\Definitions\DefRoot;

class DefLoader extends DefRoot
{

}
<?php

namespace Hobosoft\MegaLoader\Definitions;

use Hobosoft\MegaLoader\Contracts\DefInterface;

abstract class Def implements DefInterface
{
    const int ROOT = 0;
    const int CACHE = 1;
    const int LOADER = 2;
    const int LOCATOR = 3;

    public function __construct(
        protected string $type,
        protected string $name,
        protected string $className,
        protected array $children = [],
        protected ?DefInterface $parent = null,
    )
    {
    }

    public function getType(): string
    {
        return $this->type;
    }

    public function setType(string $type): void
    {
        $this->type = $type;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function setName(string $name): void
    {
        $this->name = $name;
    }

    public function getClassName(): string
    {
        return $this->className;
    }

    public function setClassName(string $className): void
    {
        $this->className = $className;
    }

    public function getParent(): DefInterface
    {
        return $this->parent;
    }

    public function setParent(DefInterface $parent): void
    {
        $this->parent = $parent;
    }

    public function getChildren(): array
    {
        return $this->children;
    }

    public function setChildren(array $childs, bool $append = false): void
    {
        if($append) {
            $this->children = array_merge($this->children, $childs);
        }
        else {
            $this->children = $childs;
        }
    }

    public static function Root(string $className): DefInterface
    {
        return new DefRoot($className);
    }

    public static function Cache(string $className): DefInterface
    {
        return new DefCache($className);
    }

    public static function Loader(string $className): DefInterface
    {
        return new DefLoader($className);
    }

    public static function Locator(string $className): DefInterface
    {
        return new DefLocator($className);
    }

    public static function Decorator(string $className): DefInterface
    {
        return new DefDecorator($className);
    }
}
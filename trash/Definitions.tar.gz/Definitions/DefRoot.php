<?php

namespace Hobosoft\MegaLoader\Definitions;

use Hobosoft\MegaLoader\Contracts\DefInterface;
use Hobosoft\MegaLoader\Definitions\Def;

class DefRoot extends Def
{
    public function __construct(
        string $className,
        array $children = [],
        ?DefInterface $parent = null,
    )
    {
        $type = explode('\\', __CLASS__);
        $type = array_pop($type);
        $type = substr($type, 3);
        parent::__construct($type, $this->name, $this->className, $this->children, $this->parent);
    }
}
